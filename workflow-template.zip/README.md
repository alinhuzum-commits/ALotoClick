# Workflow Template for SmartAutoClicker

This repository contains a GitHub Actions workflow that will automatically build an APK when you push code.

## Steps to use:
1. Create a new public repo on GitHub (e.g., SmartAutoClicker-Mod).
2. Upload all files from your Smart-AutoClicker project into the repo.
3. Also include the `.github/workflows/android.yml` file from this template.
4. Commit the changes.
5. Go to the **Actions** tab and run the workflow (or wait for auto-run on push).
6. After a few minutes, download the generated APK from the **Artifacts** section.

## Notes:
- The workflow builds a Debug APK by default.
- Download the APK and install it on your Android device (make sure you have "install unknown apps" enabled).
